//==================================================================================================
//This implementation was based on metrolist's (https://github.com/MetrolistGroup/Metrolist)
//==================================================================================================

package com.neurotube.app.data.lyrics.kugou.models

data class DownloadLyricsResponse(
    val content: String = ""
)
