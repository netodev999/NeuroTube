/*
 * Copyright (C) 2025-2026 NeuroTube | A-EDev
 *
 * This file is part of NeuroTube (https://github.com/NETO-DEV66/NeuroTube).
 */

package com.neurotube.app.data.recommendation

import java.text.BreakIterator
import java.text.Normalizer
import java.util.Locale

/**
 * How the engine reads raw text before it becomes topics: styled letters fold to plain ones, short
 * topic names survive, and scripts written without spaces are split into words (#907).
 */
internal object NeuroText {
    /** Two-letter names that are whole topics. Everything else under three letters is noise. */
    val SHORT_TOPICS = setOf("ai", "ml", "2d", "3d", "4k", "8k", "f1", "pc", "tv", "vr", "ar", "dj", "ui", "ux", "ev", "rc", "uk")

    // NFKC has no mapping for small capitals, a common way to style titles.
    private val SmallCaps =
        mapOf(
            'ᴀ' to 'a',
            'ʙ' to 'b',
            'ᴄ' to 'c',
            'ᴅ' to 'd',
            'ᴇ' to 'e',
            'ꜰ' to 'f',
            'ɢ' to 'g',
            'ʜ' to 'h',
            'ɪ' to 'i',
            'ᴊ' to 'j',
            'ᴋ' to 'k',
            'ʟ' to 'l',
            'ᴍ' to 'm',
            'ɴ' to 'n',
            'ᴏ' to 'o',
            'ᴘ' to 'p',
            'ꞯ' to 'q',
            'ʀ' to 'r',
            'ꜱ' to 's',
            'ᴛ' to 't',
            'ᴜ' to 'u',
            'ᴠ' to 'v',
            'ᴡ' to 'w',
            'ʏ' to 'y',
            'ᴢ' to 'z',
        )

    private val UnspacedScripts =
        setOf(
            Character.UnicodeScript.HAN,
            Character.UnicodeScript.HIRAGANA,
            Character.UnicodeScript.KATAKANA,
            Character.UnicodeScript.THAI,
            Character.UnicodeScript.LAO,
            Character.UnicodeScript.KHMER,
            Character.UnicodeScript.MYANMAR,
        )

    private val Whitespace = Regex("\\s+")

    private val Apostrophes = setOf('\u2019', '\u2018', '\u02BC', '`', '\u00B4')

    // Turkish dotted capital I, the emoji variation selector and joiner, and the Unicode hyphens.
    private val Marks = setOf('\u0130', '\uFE0F', '\u200D', '\u2010', '\u2011')

    private val wordBreaks = ThreadLocal.withInitial { BreakIterator.getWordInstance(Locale.ROOT) }

    /**
     * Lowercase plain letters: "𝙋𝙃𝙊𝙉𝙆", "ｐｈｏｎｋ", "ⓟⓗⓞⓝⓚ" and "ᴘʜᴏɴᴋ" all read "phonk". Every apostrophe
     * reads ', Turkish İ reads i, and emoji joiners are dropped ([NeuroKeySpec] stage 1).
     */
    fun fold(text: String): String {
        if (text.all { it.code < 0x80 }) return if ('`' in text) text.lowercase().replace('`', '\'') else text.lowercase()
        // Before NFKC, which turns ´ into a space and a combining accent.
        val marks =
            if (text.none { it in Apostrophes || it in Marks }) {
                text
            } else {
                buildString(text.length) {
                    text.forEach { c ->
                        when {
                            c in Apostrophes -> append('\'')
                            c == '\u0130' -> append('i')
                            c == '\u2010' || c == '\u2011' -> append('-')
                            c in Marks -> Unit
                            else -> append(c)
                        }
                    }
                }
            }
        // NFKC splits Thai and Lao SARA AM into two characters no dictionary or title uses; put it back.
        val normalized =
            Normalizer
                .normalize(marks, Normalizer.Form.NFKC)
                .replace("\u0E4D\u0E32", "\u0E33")
                .replace("\u0ECD\u0EB2", "\u0EB3")
        val plain = if (normalized.any { it in SmallCaps }) normalized.map { SmallCaps[it] ?: it }.joinToString("") else normalized
        return plain.lowercase()
    }

    /**
     * The words of folded text. Chinese, Japanese, Thai, Lao, Khmer and Burmese runs are split by the
     * platform's dictionary word breaker, since those scripts put no spaces between words.
     */
    fun words(folded: String): List<String> =
        folded.split(Whitespace).flatMap { chunk ->
            if (chunk.any(::isUnspaced)) segment(chunk) else listOf(chunk)
        }

    /** A letter, digit or combining mark: the marks spell vowels and tones in Thai and Devanagari words. */
    fun isWordChar(c: Char): Boolean =
        c.isLetterOrDigit() ||
            when (Character.getType(c).toByte()) {
                Character.NON_SPACING_MARK, Character.COMBINING_SPACING_MARK, Character.ENCLOSING_MARK -> true
                else -> false
            }

    /** Long enough to be a topic: three letters, a known short name, or two characters of an unspaced script. */
    fun isTopicSized(word: String): Boolean =
        when {
            word.length >= 3 -> !isGrammarKana(word)
            word in SHORT_TOPICS -> true
            word.length == 2 -> word.all(::isUnspaced) && !isGrammarKana(word)
            else -> false
        }

    private fun isUnspaced(c: Char): Boolean = !c.isWhitespace() && Character.UnicodeScript.of(c.code) in UnspacedScripts

    // Hiragana-only words are almost always particles and inflections, not subjects.
    private fun isGrammarKana(word: String): Boolean = word.all { Character.UnicodeScript.of(it.code) == Character.UnicodeScript.HIRAGANA }

    private fun segment(chunk: String): List<String> {
        val breaks = wordBreaks.get()
        breaks.setText(chunk)
        val words = ArrayList<String>()
        var start = breaks.first()
        var end = breaks.next()
        while (end != BreakIterator.DONE) {
            val word = chunk.substring(start, end)
            if (word.any(Char::isLetterOrDigit)) words += word
            start = end
            end = breaks.next()
        }
        return words
    }
}
