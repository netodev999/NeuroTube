package com.neurotube.app.data.subscriptions

/** A single `<entry>` of a YouTube channel RSS feed. */
data class ChannelRssEntry(
    val videoId: String,
    val title: String,
    val thumbnailUrl: String?,
    val publishedAtMillis: Long = 0L,
    val viewCount: Long = 0L,
    val description: String? = null,
)

/**
 * A parsed channel RSS document.
 *
 * [entries] keeps the feed's own order, which YouTube publishes newest first.
 */
data class ChannelRssFeed(
    val channelName: String?,
    val entries: List<ChannelRssEntry>,
) {
    companion object {
        val EMPTY = ChannelRssFeed(channelName = null, entries = emptyList())
    }
}
