package com.neurotube.app.data.video.downloader.work

/**
 * Watches a transfer's byte count on each progress tick and calls [onStall] once it has not moved
 * for [ticks] ticks in a row, so a stream that stops sending ends instead of holding its row still.
 */
internal class StallLimit(
    private val ticks: Int,
    val onStall: () -> Unit,
) {
    private var lastBytes = Long.MIN_VALUE
    private var stillTicks = 0

    fun stillAt(bytes: Long): Boolean {
        if (bytes != lastBytes) {
            lastBytes = bytes
            stillTicks = 0
            return false
        }
        return ++stillTicks >= ticks
    }
}
